var serverJS = {
	uploadPhotoToServer: function (deviceId, baseSring, baseSringThumb) {
		
		var postData = "dev="+deviceId+"&img="+baseSring+"&thumb="+baseSringThumb;
		sendRequest(
			'http://localhost:8888/MAD9022/FinalApp/server/save.php',
			serverJS.uploadSuccess,
			postData
		);
		
//		$.ajax({
//				url: 'http://localhost:8888/MAD9022/FinalApp/server/save.php',
//				type: 'POST',
//				dataType: "jsonp",
//				data: {
//					dev: deviceId,
//					img: baseSring,
//					thumb: baseSringThumb
//				},
//				success: function (data) {
////					alert(JSON.stringify(data));
//					alert("save sucessfully");
//				},
//				fail: function () {
//					alert("Fail to upload");
//				}
//		});
//		
	},
	uploadSuccess: function (data) {
			
		var data = JSON.stringify(data);
		alert("Added Successfully");
	},
	getListOfThumbnail: function (deviceId) {
		$.ajax({
				url: 'http://localhost:8888/MAD9022/FinalApp/server/list.php',
				type: 'GET',
				dataType: "json",
				data: {
					dev: deviceId,
				},
				success: function (data) {
					alert(JSON.stringify(data));
				},
				fail: function () {
				}
		});
	},
	deletePhoto: function (deviceId, photoId) {
		$.ajax({
				url: 'http://localhost:8888/MAD9022/FinalApp/server/delete.php',
				type: 'GET',
				dataType: "json",
				data: {
					dev: deviceId,
					img_id:photoId
				},
				success: function (data) {
					alert(JSON.stringify(data));
				},
				fail: function () {
				}
		});
	},
	getLargeImage: function (deviceId, photoId) {
		$.ajax({
				url: 'http://localhost:8888/MAD9022/FinalApp/server/get.php',
				type: 'GET',
				dataType: "json",
				data: {
					dev: deviceId,
					img_id:photoId
				},
				success: function (data) {
					alert(JSON.stringify(data));
				},
				fail: function () {
				}
		});
	},
}

// AJAX request

function createAJAXObj() {
    'use strict';
    try {
        return new XMLHttpRequest();
    } catch (er1) {
        try {
            return new ActiveXObject("Msxml3.XMLHTTP");
        } catch (er2) {
            try {
                return new ActiveXObject("Msxml2.XMLHTTP.6.0");
            } catch (er3) {
                try {
                    return new ActiveXObject("Msxml2.XMLHTTP.3.0");
                } catch (er4) {
                    try {
                        return new ActiveXObject("Msxml2.XMLHTTP");
                    } catch (er5) {
                        try {
                            return new ActiveXObject("Microsoft.XMLHTTP");
                        } catch (er6) {
                            return false;
                        }
                    }
                }
            }
        }
    }
}

function sendRequest(url, callback, postData) {
    'use strict';
    var req = createAJAXObj(), method = (postData) ? "POST" : "GET";
    if (!req) {
        return;
    }
    req.open(method, url, true);
    //req.setRequestHeader('User-Agent', 'XMLHTTP/1.0');
    if (postData) {
        req.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    }
    req.onreadystatechange = function () {
        if (req.readyState !== 4) {
            return;
        }
        if (req.status !== 200 && req.status !== 304) {
            return;
        }
        callback(req);
    }
    req.send(postData);
}
